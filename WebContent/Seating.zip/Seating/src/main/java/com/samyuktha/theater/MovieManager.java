package com.samyuktha.theater;

import java.util.Scanner;

import com.samyuktha.io.Movie;
import com.samyuktha.io.MovieSession;

public class MovieManager {
	
	private Movie movies[] = new Movie[5];
	private int nextMovieIndex = 0,count=0;
	private MovieSession sessions[] = new MovieSession[21];
	private String sessionTypes[] = {"MORNING", "EVENING", "NIGHT"};
	private String daysOfWeek[] = {"SUN","MON","TUE","WED","THUR","FRI","SAT"};

	
	public static void main(String[] args) {
		
		MovieManager manager = new MovieManager();
		manager.initializeSessions();
		Scanner input = new Scanner(System.in);
		manager.displayMenu();
		int option = input.nextInt();
		while (option !=5){
			switch(option){
				case 1:
					manager.registerNewMovie();
					break;
				case 2:
					manager.scheduleMovieSession();
					break;
				case 3:
					manager.displayMovieListing();
					break;
				case 4:
					manager.displaySessionTimes();
					break;
				default:
					System.out.println("You must enter a valid options");
			} // end switch
			
			manager.displayMenu();
			option = input.nextInt();
		}//end while
		
		

	}
	
	public void displayMenu() {
		
		System.out.println("Movie Admin Menu");
		System.out.println("++++++++++++++++++++++++++++++");
		System.out.println("Option 1. Register New Movie ");
		System.out.println("Option 2.Schedule Movie Session");
		System.out.println("Option 3. Display Movie Listing");
		System.out.println("Option 4. Display Session Times");
		System.out.println("Option 5. EXIT");
		
		System.out.print("Please Enter selection: ");	
		
	}
	
	public boolean registerNewMovie(){
		Movie movie = new Movie();
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter the Movie Title");
		movie.setTitle(input.next());
		
		System.out.print("Enter the Movie Synopsis");
		movie.setSynopsis(input.next());
		
		System.out.print("Enter the Release Date");
		movie.setReleaseDate(input.next());
		
		System.out.print("Enter the Movie Rating");
		movie.setRating(input.next());
		
		System.out.print("Enter the Movie Genre");
		movie.setGenre(input.next());
		
		System.out.print("Enter the Movie Duration");
		movie.setDuration(input.nextInt());
		
		System.out.print("Enter the Movie Distributor");
		movie.setDistributor(input.next());
		
		System.out.print("Enter the Movie Director");
		movie.setDirector(input.next());
		
		System.out.print("Enter the MovieDistributor");
		movie.setDistributor(input.next());
		
		System.out.print("Enter the Billed Cast");
		movie.setBilledCast(input.next());
		
		if(nextMovieIndex >= movies.length){
			System.out.println("Too many movies in array");
			return false;
		}
		else {
			movies[nextMovieIndex] = movie;
			nextMovieIndex++;
			count++;
			return true;
		}
		
	}
	
	public boolean scheduleMovieSession(){
		if(count!=0)
		{
		System.out.println("Select a Movie from the following to schedule");
		displayMovieListing();
		Scanner input = new Scanner(System.in);
		int i=input.nextInt();
		int temp=count;
		boolean flag=false;
		while(temp!=0)
		{
			if(temp==i){
				flag=true;
				break;
			}
			temp--;
		}
		if(flag==true){
		System.out.println("Select Movie session");
		System.out.printf("\n1. Morning\n2. Afternoon\n3. Evening\n");
		int index=input.nextInt();
		if(index==1)
		{
			movies[index-1].setSession("Morning");
		}
		else if(index==2){
			movies[index-1].setSession("Afternoon");
		}
		else{
			movies[index-1].setSession("evening");
		}
		System.out.println("Movie Scheduled");
		}
		return true;
		}
		else{
			System.out.println("No Movies to schedule!!!!!");
		return false;
	}
	}
	
	public void displayMovieListing(){
		if(count!=0)
		{
		for( int i=count;i>0;i--){
			System.out.println(i+". "+movies[i-1].getTitle());
		}
		}
		else{
			System.out.printf("\n\nNo Movies to Display!!!!\n\n");
		}
	}
	
	public void displaySessionTimes(){
		System.out.printf("\n\nsno. Movie   Session\n" +
				"-------------------------------------\n\n");
		if(count!=0)
		{
		for( int i=count;i>0;i--){
			System.out.println(i+". "+movies[i-1].getTitle()+"    "+movies[i-1].getSession());
		}
		}
		else{
			System.out.printf("\n\nNo Movies to Display!!!!\n\n");
		}
	}
	
	public void initializeSessions() {
		int count = 0;
		for(int day=0; day <daysOfWeek.length; day++){
			for(int type = 0; type <sessionTypes.length; type++){
				sessions[count] = new MovieSession(day,type);
				count++;
			}
		}
	}
	

}
