package com.samyuktha.io;


public class MovieSession {
	
	private String movieTitle;
	private int sessionType;
	private String time;
	private int day;
	
	
	public MovieSession(int sessionType, int day) {
		super();
		this.sessionType = sessionType;
		this.day = day;
	}
	
	public String getMovieTitle() {
		return movieTitle;
	}
	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}
	public int getSessionType() {
		return sessionType;
	}
	public void setSessionType(int sessionType) {
		this.sessionType = sessionType;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}

}
