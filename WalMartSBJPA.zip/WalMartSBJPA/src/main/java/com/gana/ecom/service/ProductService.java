package com.gana.ecom.service;

import java.util.List;

import com.gana.ecom.model.Product;

public interface ProductService {
	
	public void addProduct(Product employee);

	public List<Product> getAllProducts();

	public void deleteProduct(Integer employeeId);

	public Product getProduct(int employeeid);

	public void updateProduct(Product employee);
}
