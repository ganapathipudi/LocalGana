package com.gana.ecom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalMartSbwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalMartSbwsApplication.class, args);
	}
}
