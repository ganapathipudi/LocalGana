package com.gana.ecom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gana.ecom.dao.ProductRepository;
import com.gana.ecom.model.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Override
	@Transactional
	public void addProduct(Product book) {
		productRepository.save(book);
	}

	@Override
	@Transactional
	public List<Product> getAllProducts() {
		return productRepository.findAll();
	}

	@Override
	@Transactional
	public void deleteProduct(Integer bookId) {
		
		productRepository.delete(productRepository.findById(bookId).get());
	}

	public Product getProduct(int bookId) {
		return productRepository.findById(bookId).get();
	}

	public void updateProduct(Product book) {
		// TODO Auto-generated method stub
		productRepository.save(book);
	}
}
