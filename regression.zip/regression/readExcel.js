'use strict';

var fs = require('fs');
var _ = require('lodash');

var Excel = require('exceljs');

var HrStopwatch = require('./utils/hr-stopwatch');

process.argv = ['node', 'CountryIn.xlsx','CountryOUT.xlsx']

var filename = process.argv[1];
var outputfilename=process.argv[2];
console.log('Input File name',filename);

var wb = new Excel.Workbook();

var stopwatch = new HrStopwatch();
stopwatch.start();

// assuming file created by testBookOut
wb.xlsx.readFile(filename)
  .then(function() {
    var micros = stopwatch.microseconds;

    console.log('Loaded', filename);
    console.log('Time taken:', micros);

    var ws = wb.getWorksheet("NJ");


    var column1 = ws.getColumn(1);
	console.log(column1);
    var column9 = ws.getColumn(9);

    var row2 = ws.getRow(2);
	console.log("second Row",row2);
	
	console.log(ws.getCell("A2").value);
    console.log(ws.getCell("B2").value); 
	console.log(ws.getCell("C2").value);
	
  });
  var Workbook = Excel.Workbook;
  var owb = new Workbook();
var ows = wb.addWorksheet("CA");
ows.columns = [
  { header: "Col 1", key:"S.No", width: 25 },
  { header: "Col 2", key:"name", width: 32 },
  { header: "Col 3", key:"Profession", width: 21 }
];

ows.getCell("A2").value = 1;
ows.getCell("B2").value = "ShreeOut";
ows.getCell("C2").value = "IT";
  owb.xlsx.writeFile(outputfilename)
  .then(function(){
      });
