package com.gana.dto;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class TestApp {
	public static void main(String[] args) {

		SessionFactory factory = new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();

		Session session = factory.openSession();

		Transaction transaction = session.beginTransaction();

		
		Query query = session.createQuery("from Customer where name='Ganapathi' ");

		List<Customer> customers = query.list();

		for (Customer customer2 : customers) {
			System.out.println(customer2.getId());
			System.out.println(customer2.getName());
			
		}
		
		Criteria criteria = session.createCriteria(Customer.class);
		criteria.add(Restrictions.eq("name", "Ganapathi"));
		List<Customer> customers1 = criteria.list();

		for (Customer customer2 : customers) {
			System.out.println(customer2.getId());
			System.out.println(customer2.getName());
			
		}	
	
		
		transaction.commit();

	}

}
