package com.gana.dto;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class TestApp {
	public static void main(String[] args) {

		SessionFactory factory = new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();

		Session session = factory.openSession();
		System.out.println("Hibernate many to many (Annotation)");

		Transaction transaction = session.beginTransaction();

		Address address = new Address();

		address.setLocation("Sivaji nagar,HYD");
		address.setType(1);

		session.save(address);

		System.out.println("Done");

		Query query = session.createQuery("from Address");

		List<Address> addresses = query.list();

		for (Address address2 : addresses) {
			System.out.println(address2.getLocation());
		}

		transaction.commit();

	}

}
