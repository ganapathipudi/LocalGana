package com.gana.hibernate.test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.gana.hibernate.dto.Employees;

public class TestApp {
	public static void main(String[] args) {
		SessionFactory sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		Query q = session.createQuery("from Employees");
		List<Employees> list = q.list();
		for (Employees app : list) {
			System.out.println(app.getEmployeeName());
			System.out.println(app.getEmployeeEmail());
			System.out.println("-------------------");
		}
	}

	public static void main1(String[] args) {

		Employees em1 = new Employees();
		Employees em2 = new Employees();
		Employees em3 = new Employees();

		System.out.println(" =======CREATE =======");
		create(em1);
		create(em2);
		create(em3);
		System.out.println(" =======READ =======");
		List<Employees> ems1 = read();
		for (Employees e : ems1) {
			System.out.println(e.toString());
		}
		System.out.println(" =======UPDATE =======");
		em1.setEmployeeName("Mary Rose");
		update(em1);
		System.out.println(" =======READ =======");
		List<Employees> ems2 = read();
		for (Employees e : ems2) {
			System.out.println(e.toString());
		}
		System.out.println(" =======DELETE ======= ");
		delete(em2.getEmployeeId());
		System.out.println(" =======READ =======");
		List<Employees> ems3 = read();
		for (Employees e : ems3) {
			System.out.println(e.toString());
		}
		System.out.println(" =======DELETE ALL ======= ");
		deleteAll();
		System.out.println(" =======READ =======");
		List<Employees> ems4 = read();
		for (Employees e : ems4) {
			System.out.println(e.toString());
		}
		System.exit(0);
	}

	public static SessionFactory getSessionFactory() {
		return new AnnotationConfiguration().configure().buildSessionFactory();

	}

	public static Integer create(Employees e) {
		Session session = getSessionFactory().openSession();
		session.beginTransaction();
		session.save(e);
		session.getTransaction().commit();
		session.close();
		System.out.println("Successfully created " + e.toString());
		return e.getEmployeeId();

	}

	public static List<Employees> read() {
		Session session = getSessionFactory().openSession();
		@SuppressWarnings("unchecked")
		List<Employees> employees = session.createQuery("FROM Employees").list();
		session.close();
		System.out.println("Found " + employees.size() + " Employees");
		return employees;

	}

	public static void update(Employees e) {
		Session session = getSessionFactory().openSession();
		session.beginTransaction();
		Employees em = (Employees) session.load(Employees.class, e.getEmployeeId());
		em.setEmployeeName(e.getEmployeeName());
		em.setEmployeeId(e.getEmployeeId());
		session.getTransaction().commit();
		session.close();
		System.out.println("Successfully updated " + e.toString());

	}

	public static void delete(Integer id) {
		Session session = getSessionFactory().openSession();
		session.beginTransaction();
		Employees e = findByID(id);
		session.delete(e);
		session.getTransaction().commit();
		session.close();
		System.out.println("Successfully deleted " + e.toString());

	}

	public static Employees findByID(Integer id) {
		Session session = getSessionFactory().openSession();
		Employees e = (Employees) session.load(Employees.class, id);
		session.close();
		return e;
	}

	public static void deleteAll() {
		Session session = getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.createQuery("DELETE FROM Employees ");
		//query.
		session.getTransaction().commit();
		session.close();
		System.out.println("Successfully deleted all employees.");

	}
}
