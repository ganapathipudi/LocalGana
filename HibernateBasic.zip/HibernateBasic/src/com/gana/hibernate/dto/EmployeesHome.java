package com.gana.hibernate.dto;
// Generated 3 Apr, 2018 8:47:48 PM by Hibernate Tools 5.2.8.Final

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class Employees.
 * @see com.gana.hibernate.dto.Employees
 * @author Hibernate Tools
 */
public class EmployeesHome {

	private static final Log log = LogFactory.getLog(EmployeesHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(Employees transientInstance) {
		log.debug("persisting Employees instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(Employees persistentInstance) {
		log.debug("removing Employees instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public Employees merge(Employees detachedInstance) {
		log.debug("merging Employees instance");
		try {
			Employees result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Employees findById(Integer id) {
		log.debug("getting Employees instance with id: " + id);
		try {
			Employees instance = entityManager.find(Employees.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
